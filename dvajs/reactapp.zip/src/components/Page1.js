import React from 'react';

const Page1 = () => {
  return (
    <div>
      I am page1
    </div>
  );
};

Page1.propTypes = {
};

export default Page1;
