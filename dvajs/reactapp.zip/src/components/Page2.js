import React from 'react';

const Page2 = () => {
  return (
    <div>
      I am page2
    </div>
  );
};

Page2.propTypes = {
};

export default Page2;
