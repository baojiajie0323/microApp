const packageName = require('./package.json').name;
export default function (webpackConfig) {
    var newWebpackConfig = {
        ...webpackConfig,
        output: {
            ...webpackConfig.output,
            library: `${packageName}-[name]`,
            libraryTarget: 'umd',
            jsonpFunction: `webpackJsonp_${packageName}`,
            // globalObject : 'window'
        }
    }

    return newWebpackConfig;
}